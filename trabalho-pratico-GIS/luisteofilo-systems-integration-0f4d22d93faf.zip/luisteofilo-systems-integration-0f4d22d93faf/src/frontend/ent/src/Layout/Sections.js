import Players from "../Tables/Players";

const Sections = [

    {
        id: "players",
        label: "Players",
        content: <Players/>
    },

    {
        id: "teams",
        label: "Teams",
        content: <h1>Teams - Work in progresss</h1>
    },

    {
        id: "countries",
        label: "Countries",
        content: <h1>Countries - Work in progress</h1>
    }

];

export default Sections;