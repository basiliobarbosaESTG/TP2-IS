SELECT * FROM converted_documents

SELECT * FROM imported_documents

DELETE FROM converted_documents;
DELETE FROM imported_documents
