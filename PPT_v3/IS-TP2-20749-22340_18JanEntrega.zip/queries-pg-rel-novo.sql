SELECT * FROM season;

DELETE FROM season;

SELECT * FROM atlethe;

DELETE FROM atlethe;

--INSERT INTO atlethe(name, sex, age, height, weight, team, noc, games, year, season, city, lat, lon, sport, event, medal, geom) VALUES ('name', 'sex', 'age', 'height', 'weight', 'team', 'noc', 'games', 'year', 'season', 'city', 'lat', 'lon', 'sport', 'event', 'medal', null)