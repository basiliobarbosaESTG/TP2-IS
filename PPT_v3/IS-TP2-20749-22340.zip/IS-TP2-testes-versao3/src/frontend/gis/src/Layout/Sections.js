import ObjectsMap from "../Map/ObjectsMap";

const Sections = [

    {
        id: "map",
        label: "Map",
        content: <ObjectsMap/>
    }

];

export default Sections;