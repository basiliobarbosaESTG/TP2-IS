import React from "react";
import AtletheTables from "./AtletheTables";

function Atlethe() {
    return (
        <>
            <div className="d-flex flex-column align-itens-center">
                <h1>Dados API Athletes</h1>
            </div>
            <AtletheTables />
        </>
    );
}

export default Atlethe;