import Season from "../Tables/Season"
import Atlethe from "../Tables/Atlethe";

const Sections = [

    {
        id: "atlethes",
        label: "Atlethes",
        content: < Atlethe />
    },

    {
        id: "seasons",
        label: "Seasons",
        content: < Season />
    },

    // {
    //     id: "countries",
    //     label: "Countries",
    //     content: <h1>Countries - Work in progress</h1>
    // }
];

export default Sections;