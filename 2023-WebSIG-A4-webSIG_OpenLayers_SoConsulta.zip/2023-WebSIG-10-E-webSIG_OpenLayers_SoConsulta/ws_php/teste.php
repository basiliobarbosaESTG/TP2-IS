<?php
if (isset($_POST['designation'])) {
	$name = strip_tags($_POST['designation']);
	 
	echo "<strong>Designacao:</strong>: ".$designation."</br>"; 
	 
}
?>