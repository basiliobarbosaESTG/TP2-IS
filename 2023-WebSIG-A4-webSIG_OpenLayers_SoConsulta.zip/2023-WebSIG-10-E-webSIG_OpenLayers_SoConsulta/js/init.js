window.onload = init;

function init(){
	
		// editedLayers
		var editedLayers= new ol.layer.Group({
			title: 'Layers Editáveis (Ocorrências)',
		
		layers: [
			new ol.layer.Tile({
				title: 'Ocorrências - Linhas',
				source:  new ol.source.TileWMS({
					url: 'http://localhost:8080/geoserver/wms',
					params: {'LAYERS': 'Aulas_SIG:occurrences_line'},
					serverType: 'geoserver'
				}),
				isBaseLayer: true,
				visible:false,
				opacity:1,
				crossOrigin: 'anonymous',			
			  }),
			new ol.layer.Tile({
				title: 'Ocorrências - Pontos',
				source:  new ol.source.TileWMS({
					url: 'http://localhost:8080/geoserver/wms',
					params: {'LAYERS': 'Aulas_SIG:occurrences_point'},
					serverType: 'geoserver'
				}),
				isBaseLayer: true,
				visible:false,
				opacity:1,
				crossOrigin: 'anonymous',			
			  }),
			new ol.layer.Tile({
				title: 'Ocorrências - Areas',
				source:  new ol.source.TileWMS({
					url: 'http://localhost:8080/geoserver/wms',
					params: {'LAYERS': 'Aulas_SIG:occurrences_polygon'},
					serverType: 'geoserver'
				}),
				isBaseLayer: true,
				visible:false,
				opacity:1,
				crossOrigin: 'anonymous',			
			  }),
			 
								 
			]
		});

    
	// Overlays
	var overlays = new ol.layer.Group({
		title: 'Layers Temáticas (Consulta)',
	
	layers: [
		new ol.layer.Tile({
			title: 'Uso do Solo',
			source:  new ol.source.TileWMS({
				url: 'http://localhost:8080/geoserver/wms',
				params: {'LAYERS': 'Aulas_SIG:ifn_2015'},
				serverType: 'geoserver'
			}),
			isBaseLayer: true,
			visible:false,
			opacity:1,
			crossOrigin: 'anonymous',			
		  }),
		new ol.layer.Tile({
			title: 'Pontos de Água',
			source:  new ol.source.TileWMS({
				url: 'http://localhost:8080/geoserver/wms',
				params: {'LAYERS': 'Aulas_SIG:pontos_agua'},
				serverType: 'geoserver'
			}),
			isBaseLayer: true,
			visible:false,
			opacity:1,
			crossOrigin: 'anonymous',			
		  }),
		new ol.layer.Tile({
			title: 'Zonas de Caça',
			source:  new ol.source.TileWMS({
				url: 'http://localhost:8080/geoserver/wms',
				params: {'LAYERS': 'Aulas_SIG:zonas_caca'},
				serverType: 'geoserver'
			}),
			isBaseLayer: true,
			visible:false,
			opacity:1,
			crossOrigin: 'anonymous',			
		  }),
		new ol.layer.Tile({
			title: 'Área Ardida',
			source:  new ol.source.TileWMS({
				url: 'http://localhost:8080/geoserver/wms',
				params: {'LAYERS': 'Aulas_SIG:ardida_2018'},
				serverType: 'geoserver'
			}),
			isBaseLayer: true,
			visible:false,
			opacity:1,
			crossOrigin: 'anonymous',			
		  }),	 
		new ol.layer.Tile({
			title: 'Rede Viária',
			source:  new ol.source.TileWMS({
				url: 'http://localhost:8080/geoserver/wms',
				params: {'LAYERS': 'Aulas_SIG:rede_viaria'},
				serverType: 'geoserver'
			}),
			visible: false,
			opacity:1
		}),
		new ol.layer.Tile({
			title: 'CAOP',
			source:  new ol.source.TileWMS({
				url: 'http://localhost:8080/geoserver/wms',
				params: {'LAYERS': 'Aulas_SIG:cont_aad_caop2015'},
				serverType: 'geoserver'
			}),
			isBaseLayer: true,
			visible:true,
			opacity:1,
			crossOrigin: 'anonymous',			
		}),	
							 
		]
	});

	// Baselayers
	var baselayers = new ol.layer.Group({
		title: 'Layers Base',
		
		layers: [
	
			new ol.layer.Tile({
				title: 'ESRI Map',
				type: 'base',	
				className: 'bw',
				visible: false,			
				source: new ol.source.XYZ({
					url: 'http://server.arcgisonline.com/ArcGIS/rest/services/' +
				    	'World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
				})
			}),			
			new ol.layer.Tile({
				title: 'ESRI Satellite Map',
				type: 'base',
				visible: false,				
				source: new ol.source.XYZ({
					url: 'http://server.arcgisonline.com/ArcGIS/rest/services/' +
				    	'World_Imagery/MapServer/tile/{z}/{y}/{x}'
				})
			}),			
			new ol.layer.Tile({
				title: 'ESRI Street Map',
				type: 'base',
				visible: false,
				source: new ol.source.XYZ({
					url: 'http://server.arcgisonline.com/ArcGIS/rest/services/' +
				    	'World_Street_Map/MapServer/tile/{z}/{y}/{x}'
				})
			}),
			new ol.layer.Tile({
				title: 'Bing Maps Sattelite',
				visible: false,
				type: 'base',	source: new ol.source.BingMaps({
				key: 'AjcLcBLUBKZDvAoCuvtu_7KWFp4fAvY2SXeHmklGWoictZ6A7Yu83ayg87SrAlST',
				imagerySet: 'AerialWithLabels', /* 'Road', 'Aerial', 'AerialWithLabels', 'collinsBart', 'ordnanceSurvey' */
				maxZoom: 19})		
		    }),
			new ol.layer.Tile({
				title: 'Open Street Map',
				visible: true,
				type: 'base',
				source: new ol.source.OSM()
			}) 
		 
		]
	});

	// Map Layers
	var layers = [		
		baselayers,
		editedLayers,
		overlays,
		
		
	];

	// Map Controls
  	var controls = [
		new ol.control.Zoom(),
  		new ol.control.OverviewMap(),
  		new ol.control.Attribution(),
  		new ol.control.ScaleLine(),
  		new ol.control.Rotate()
  	];

  	// Map View
	var view = new ol.View({
		//projection: 'EPSG:4326',
		//center: [-10997148, 4569099],
		
		center: [-983136, 5115403],
		zoom: 7,
		minZoom: 3,
		maxZoom: 20
	});

	// Map
	var map = new ol.Map({
		layers: layers,
		controls: controls,
		target: 'map',
		view: view
	});

	// LayerSwitcher
    var layerSwitcher = new ol.control.LayerSwitcher({
        tipLabel: 'Layer Control' // Optional label for button
    });
    map.addControl(layerSwitcher);

	// Geocoder
	var geocoder = new Geocoder('nominatim', {
		provider: 'photon',
		lang: 'en',
		placeholder: 'Search for ...',
		limit: 5,
		debug: true,
		autoComplete: true,
		keepOpen: true
	});
	map.addControl(geocoder);

	// Context Menu
	var add_marker = function(){
        $('#modalAddPoint').modal('show');
	};
	var zoom_extent = function(){
		map.setView(
			new ol.View({
				center: [-10997148, 4569099],
				zoom: 4,
				minZoom: 4,
				maxZoom: 20
			})
		);		
		console.log(view.calculateExtent(map.getSize()));
	};
	var download_png = function(){
        map.once('postcompose', function(event) {
          var canvas = event.context.canvas;
          canvas.toBlob(function(blob) {
            saveAs(blob, 'map.png');
          });
        });
        map.renderSync();		
	};

	var measure_line = function(){
		alert("A IMPLEMENTAR FUNCIONALIDADE");  
	}

	var measure_area = function(){
		alert("A IMPLEMENTAR FUNCIONALIDADE");  
	}

	var add_geolocation = function(){
		// set up geolocation to track our position
		var geolocation = new ol.Geolocation({
			tracking: true,
			projection: view.getProjection()
		});
		
		geolocation.on('change:position', function() {
			var center = geolocation.getPosition();
			console.log(center[0]);
			view.setCenter(center);
			view.setZoom(16);
		});
	};

	var contextmenu = new ContextMenu({
		width: 170,
		defaultItems: false, // defaultItems are (for now) Zoom In/Zoom Out
		items: [
			{
				text: 'Add Marker',
				icon: './plugins/contextmenu/img/marker.png',
				callback: add_marker

			},
			{
				text: 'Geolocation',
				icon: './plugins/contextmenu/img/geolocation.png',
				callback: add_geolocation
			},						
			{
				text: 'Zoom Extent',
				icon: './plugins/contextmenu/img/center.png',
				callback: zoom_extent

			},
			'-',
			{
				text: 'Measure Line',
				icon: './plugins/contextmenu/img/measure_line.png',
				callback: measure_line

			},
			{
				text: 'Measure Area',
				icon: './plugins/contextmenu/img/measure_area.png',
				callback: measure_area

			},
			'-',
			{
				text: 'Save as PNG',
				icon: './plugins/contextmenu/img/save_png.png',
				callback: download_png
			}			
		]
	});
	map.addControl(contextmenu);

}